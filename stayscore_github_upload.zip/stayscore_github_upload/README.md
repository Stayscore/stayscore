# StayScore – GitHub Upload Paket

Lade **den Inhalt dieses Ordners** (die Ordner `backend/` und `admin-web/`) in dein GitHub-Repository hoch.
Nicht die ZIP selbst hochladen, sondern vorher entpacken und die beiden Ordner in GitHub **Add file → Upload files** ziehen.

## Kurzleitfaden Deployment
- **Render Web Service (Backend)**
  - Root directory: `backend`
  - Build: `npm install`
  - Start: `npm run start:render`
  - ENVs: POSTGRES_HOST, POSTGRES_PORT=5432, POSTGRES_DB, POSTGRES_USER, POSTGRES_PASSWORD, APP_PORT=8080, JWT_SECRET=stayscore_demo_secret, SEED_DEMO=1, APP_ORIGIN=<deine Vercel-URL>

- **Vercel (Admin-Web)**
  - Root directory: `admin-web`
  - Build: `npm install && npm run build`
  - Output: `dist`
  - ENV: `VITE_API_BASE` = <deine Render-Backend-URL>